# Science Calculator Pro

Native Android scientific calculator written in Kotlin with Jetpack Compose and Material 3.

- **Application ID / namespace:** `com.smb.scientificcalculator`
- **Minimum Android:** API 23 (Android 6.0)
- **Target SDK:** 35
- **Language/UI:** Kotlin, Jetpack Compose, Material 3
- **Internet/API keys:** Not used by the calculator
- **Local storage:** Android SharedPreferences stores settings and calculation history as local JSON

## Included features

### Scientific calculator

Basic arithmetic, parentheses, precedence, decimal/scientific notation, powers, square/cube roots, reciprocal, factorial, percentage postfix, trigonometric and inverse trigonometric functions, hyperbolic functions, logarithms, exponentials, constants, `Ans`, memory (MC/MR/M+/M−/MS), degree/radian mode, clipboard copy/paste, permutations, combinations, GCD/LCM, modulo, random values, percentage change, significant figures, and configurable rounding display. User expressions are parsed by a custom recursive-descent parser; input is never executed as code.

Some supported typed expressions include `root(27,3)`, `logb(8,2)`, `ncr(5,2)`, `npr(5,2)`, `mod(11,4)`, `pctchange(100,120)`, `sig(1234.567,3)`, `rand()` and `random(1,10)`.

### Time tools

Duration add/subtract, clock-time difference (including an optional midnight crossing), date/time difference, stopwatch with lap records, countdown timer with named saved presets, and time-unit conversions. Stopwatch and timer use monotonic/deadline timestamps so elapsed values recalculate accurately when the UI resumes. The current implementation does not keep a foreground service or show timer-completion notifications while the app is closed.

### Unit converter

Length, weight, area, volume, speed, temperature, energy, pressure, data storage, angle, frequency and time. Conversions are calculated locally. Data storage uses decimal units (1 KB = 1,000 bytes).

### Advanced mathematics

Linear and quadratic equation solvers (including complex roots), summary statistics, up-to-3×3 matrix operations, a graph plotter for parser-supported expressions, decimal/fraction conversion, and common scientific constants.

### History/settings

Calculation history is timestamped, searchable, reusable, copyable, favouritable, individually deletable, and persisted locally. Settings include light/dark/system theme, angle mode, decimal precision, number grouping, haptic feedback, click sound, time format, auto-clear-history, reset settings and About information.

## Build in Android Studio

1. Install **Android Studio** with an Android SDK platform for API 35 and JDK 17.
2. Open the `ScienceCalculatorProProject` folder (the folder containing `settings.gradle.kts`).
3. Allow Gradle to sync and download the declared AndroidX/Compose dependencies. The first sync requires network access.
4. Choose **Build → Make Project** to compile.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. Android Studio usually places the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

Command line, on a machine with network access:

```bash
./gradlew :app:assembleDebug
```

The included `gradlew` launcher uses an installed Gradle if available; otherwise, it attempts to download Gradle 8.9 into the user's Gradle cache. The Windows launcher works similarly through PowerShell. If the environment is offline, install Gradle 8.9 first.

## Signed release APK

In Android Studio, select **Build → Generate Signed Bundle / APK → APK → Create new**. Create and safely back up a keystore, choose the `release` build variant, then finish the wizard. Do not commit or share keystore files/passwords. With a configured Android SDK and Gradle, a release build can also be generated with `./gradlew :app:assembleRelease`; signing must be configured separately if you want that output signed automatically.

## Tests

Unit tests cover core parser behavior, mathematical errors, time differences, unit conversion, statistics, matrix determinants and fraction conversion. Run them from Android Studio or with:

```bash
./gradlew :app:testDebugUnitTest
```

## Build verification status for this package

The pure Kotlin calculation engines were compiled with `kotlinc` in the creation environment and exercised with smoke tests. This environment did not have the Android SDK or Gradle installed and could not reach external download hosts, so a full Android/Compose build, emulator run, and APK install test could not be performed here. Build the project in Android Studio to generate the installable APK.
