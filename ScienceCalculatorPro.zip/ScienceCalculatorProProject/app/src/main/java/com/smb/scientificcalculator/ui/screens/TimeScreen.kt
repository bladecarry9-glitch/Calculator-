package com.smb.scientificcalculator.ui.screens

import com.smb.scientificcalculator.ui.SectionTitle

import android.os.SystemClock
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smb.scientificcalculator.time.TimeEngine
import kotlinx.coroutines.delay
import java.time.Duration
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@Composable
fun TimeScreen(time24h: Boolean) {
    var mode by remember { mutableStateOf("Duration") }
    val modes = listOf("Duration", "Difference", "Time shift", "Date diff", "Stopwatch", "Timer", "Units")
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SectionTitle("Time tools", "Durations, clocks, stopwatch and countdown")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            modes.forEach { item -> FilterChip(selected = mode == item, onClick = { mode = item }, label = { Text(item, fontSize = 12.sp) }) }
        }
        when (mode) {
            "Duration" -> DurationCalculator()
            "Difference" -> DifferenceCalculator(time24h)
            "Time shift" -> TimeShiftCalculator(time24h)
            "Date diff" -> DateDifferenceCalculator()
            "Stopwatch" -> StopwatchTool()
            "Timer" -> CountdownTool()
            "Units" -> TimeUnitTool()
        }
    }
}

@Composable
private fun DurationCalculator() {
    var hours by remember { mutableStateOf("1") }; var minutes by remember { mutableStateOf("30") }; var seconds by remember { mutableStateOf("0") }
    var otherH by remember { mutableStateOf("0") }; var otherM by remember { mutableStateOf("15") }; var otherS by remember { mutableStateOf("0") }
    var op by remember { mutableStateOf("Add") }
    val calc = runCatching {
        val a = TimeEngine.toSeconds(hours.toLong(), minutes.toLong(), seconds.toLong())
        val b = TimeEngine.toSeconds(otherH.toLong(), otherM.toLong(), otherS.toLong())
        val total = if (op == "Add") a + b else a - b
        "${TimeEngine.formatDuration(total)}\n${total} seconds • ${"%.4f".format(java.util.Locale.US, total / 60.0)} minutes • ${"%.4f".format(java.util.Locale.US, total / 3600.0)} hours"
    }.getOrElse { "Enter valid whole-number hours, minutes and seconds." }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Time arithmetic", style = MaterialTheme.typography.titleMedium)
            Text("Duration A", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Hours", hours, { hours = it }, Modifier.weight(1f)); NumberField("Minutes", minutes, { minutes = it }, Modifier.weight(1f)); NumberField("Seconds", seconds, { seconds = it }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Add", "Subtract").forEach { FilterChip(selected = op == it, onClick = { op = it }, label = { Text(it) }) } }
            Text("Duration B", fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NumberField("Hours", otherH, { otherH = it }, Modifier.weight(1f)); NumberField("Minutes", otherM, { otherM = it }, Modifier.weight(1f)); NumberField("Seconds", otherS, { otherS = it }, Modifier.weight(1f))
            }
        }
    }
    ResultCard(calc)
}

@Composable
private fun DifferenceCalculator(time24h: Boolean) {
    var start by remember { mutableStateOf(if (time24h) "09:00:00" else "09:00 AM") }
    var end by remember { mutableStateOf(if (time24h) "17:30:00" else "05:30 PM") }
    var crosses by remember { mutableStateOf(true) }
    val result = runCatching {
        val sec = TimeEngine.clockDifference(start, end, crosses)
        "${TimeEngine.formatDuration(sec)}\n$sec seconds • ${"%.4f".format(java.util.Locale.US, sec/60.0)} minutes • ${"%.4f".format(java.util.Locale.US, sec/3600.0)} hours"
    }.getOrElse { it.message ?: "Invalid time" }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Time difference", style = MaterialTheme.typography.titleMedium)
            Text(if (time24h) "Use HH:MM or HH:MM:SS (24-hour input)" else "Use 12-hour clock input, e.g. 09:00 AM or 05:30 PM", fontSize = 12.sp)
            NumberField("Start time", start, { start = it }, Modifier.fillMaxWidth())
            NumberField("End time", end, { end = it }, Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) { Text("End time may cross midnight", modifier = Modifier.weight(1f), fontSize = 13.sp); Switch(crosses, { crosses = it }) }
        }
    }
    ResultCard(result)
}


@Composable
private fun TimeShiftCalculator(time24h: Boolean) {
    var start by remember { mutableStateOf(if (time24h) "09:30:00" else "09:30 AM") }
    var hours by remember { mutableStateOf("2") }; var minutes by remember { mutableStateOf("15") }; var seconds by remember { mutableStateOf("0") }
    var operation by remember { mutableStateOf("Add") }
    val result = runCatching {
        val base = TimeEngine.parseClock(start)
        val duration = TimeEngine.toSeconds(hours.toLong(), minutes.toLong(), seconds.toLong())
        val signed = if (operation == "Add") duration else -duration
        "Resulting time: ${TimeEngine.formatClock(base.toLong() + signed, time24h)}\nDuration applied: ${TimeEngine.formatDuration(signed)}"
    }.getOrElse { it.message ?: "Enter valid time and duration" }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Add or subtract a duration from a starting clock time", style = MaterialTheme.typography.titleMedium)
        NumberField(if (time24h) "Starting time (HH:MM:SS)" else "Starting time (e.g. 09:30 AM)", start, { start = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("Hours", hours, { hours = it }, Modifier.weight(1f))
            NumberField("Minutes", minutes, { minutes = it }, Modifier.weight(1f))
            NumberField("Seconds", seconds, { seconds = it }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("Add", "Subtract").forEach { FilterChip(selected = operation == it, onClick = { operation = it }, label = { Text(it) }) } }
        ResultCard(result)
    }
}

@Composable
private fun DateDifferenceCalculator() {
    val fmt = remember { DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss") }
    var start by remember { mutableStateOf("2026-10-22 09:00:00") }
    var end by remember { mutableStateOf("2026-10-22 17:30:00") }
    val result = runCatching {
        val a = LocalDateTime.parse(start, fmt); val b = LocalDateTime.parse(end, fmt)
        val sec = Duration.between(a, b).seconds
        "${TimeEngine.formatDuration(sec)}\n${sec} seconds • ${sec / 60.0} minutes • ${sec / 3600.0} hours • ${sec / 86400.0} days"
    }.getOrElse { "Use format YYYY-MM-DD HH:MM:SS. ${it.message ?: "Invalid date/time"}" }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Enter both date and time in 24-hour format", fontSize = 12.sp)
        NumberField("Start date & time", start, { start = it }, Modifier.fillMaxWidth())
        NumberField("End date & time", end, { end = it }, Modifier.fillMaxWidth())
        ResultCard(result)
    }
}

@Composable
private fun StopwatchTool() {
    var running by remember { mutableStateOf(false) }; var startedAt by remember { mutableLongStateOf(0L) }; var accumulated by remember { mutableLongStateOf(0L) }; var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    val laps = remember { mutableStateListOf<String>() }
    LaunchedEffect(running) { while (running) { now = SystemClock.elapsedRealtime(); delay(80) } }
    val elapsed = accumulated + if (running) (now - startedAt).coerceAtLeast(0) else 0L
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Stopwatch", style = MaterialTheme.typography.titleMedium)
            Text(TimeEngine.formatDuration(elapsed / 1000), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { if (running) { accumulated += (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0); running = false } else { startedAt = SystemClock.elapsedRealtime(); now = startedAt; running = true } }) { Text(if (running) "Pause" else if (accumulated > 0) "Resume" else "Start") }
                OutlinedButton(onClick = { laps.add("Lap ${laps.size + 1}: ${TimeEngine.formatDuration(elapsed / 1000)}"); }, enabled = elapsed > 0) { Text("Lap") }
                OutlinedButton(onClick = { running = false; accumulated = 0; now = SystemClock.elapsedRealtime(); laps.clear() }) { Text("Reset") }
            }
        }
    }
    if (laps.isNotEmpty()) {
        Text("Lap records", style = MaterialTheme.typography.titleSmall)
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 200.dp)) { items(laps.reversed()) { Text(it, Modifier.fillMaxWidth().padding(vertical = 5.dp)) } }
    }
}

@Composable
private fun CountdownTool() {
    var name by remember { mutableStateOf("Focus timer") }; var input by remember { mutableStateOf("300") }
    var remaining by remember { mutableLongStateOf(300_000L) }; var deadline by remember { mutableLongStateOf(0L) }; var running by remember { mutableStateOf(false) }; var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    val presets = remember { mutableStateListOf<Pair<String, Long>>() }
    LaunchedEffect(running) {
        while (running) {
            now = SystemClock.elapsedRealtime(); remaining = (deadline - now).coerceAtLeast(0L)
            if (remaining <= 0L) { running = false; remaining = 0L }
            delay(150)
        }
    }
    val shown = if (running) (deadline - now).coerceAtLeast(0L) else remaining
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(name, style = MaterialTheme.typography.titleMedium)
            Text(TimeEngine.formatDuration((shown / 1000L)), style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            NumberField("Timer name", name, { name = it }, Modifier.fillMaxWidth())
            NumberField("Duration in seconds", input, { input = it; if (!running) remaining = (it.toLongOrNull()?.coerceAtLeast(0) ?: 0) * 1000 }, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    if (running) { remaining = (deadline - SystemClock.elapsedRealtime()).coerceAtLeast(0); running = false }
                    else { val ms = if (remaining > 0) remaining else (input.toLongOrNull()?.coerceAtLeast(0) ?: 0) * 1000; remaining = ms; deadline = SystemClock.elapsedRealtime() + ms; running = ms > 0 }
                }) { Text(if (running) "Pause" else if (remaining < (input.toLongOrNull() ?: 0) * 1000L && remaining > 0) "Resume" else "Start") }
                OutlinedButton(onClick = { running = false; remaining = (input.toLongOrNull()?.coerceAtLeast(0) ?: 0) * 1000; now = SystemClock.elapsedRealtime() }) { Text("Reset") }
                OutlinedButton(onClick = { val sec = input.toLongOrNull(); if (sec != null && sec > 0) presets.add((name.ifBlank { "Timer ${presets.size + 1}" }) to sec * 1000) }) { Text("Save") }
            }
        }
    }
    if (presets.isNotEmpty()) {
        Text("Saved named timers", style = MaterialTheme.typography.titleSmall)
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            presets.forEach { item -> OutlinedButton(onClick = { name = item.first; input = (item.second/1000).toString(); remaining = item.second; running = false }, modifier = Modifier.fillMaxWidth()) { Text("${item.first} • ${TimeEngine.formatDuration(item.second/1000)}") } }
        }
    }
}

@Composable
private fun TimeUnitTool() {
    val units = listOf("Milliseconds", "Seconds", "Minutes", "Hours", "Days", "Weeks")
    val factors = mapOf("Milliseconds" to .001, "Seconds" to 1.0, "Minutes" to 60.0, "Hours" to 3600.0, "Days" to 86400.0, "Weeks" to 604800.0)
    var value by remember { mutableStateOf("1") }; var from by remember { mutableStateOf("Hours") }; var to by remember { mutableStateOf("Minutes") }
    val result = runCatching { value.toDouble() * factors.getValue(from) / factors.getValue(to) }.getOrNull()
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NumberField("Value", value, { value = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceMenu("From", from, units, { from = it }, Modifier.weight(1f))
            ChoiceMenu("To", to, units, { to = it }, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { val t=from; from=to; to=t }, modifier = Modifier.weight(1f)) { Text("Swap units") } }
        ResultCard(result?.let { "${"%.10g".format(java.util.Locale.US, it)} $to" } ?: "Enter a valid value")
    }
}
