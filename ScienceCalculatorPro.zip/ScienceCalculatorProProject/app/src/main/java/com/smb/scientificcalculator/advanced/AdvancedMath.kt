package com.smb.scientificcalculator.advanced

import com.smb.scientificcalculator.core.CalculatorEngine
import kotlin.math.*

data class StatisticsResult(val count: Int, val sum: Double, val mean: Double, val median: Double, val modes: List<Double>, val min: Double, val max: Double, val range: Double, val variance: Double, val stdDev: Double)
object AdvancedMath {
    fun solveLinear(a: Double, b: Double): String {
        require(a.isFinite() && b.isFinite())
        return when { a == 0.0 && b == 0.0 -> "Every real number is a solution"; a == 0.0 -> "No solution"; else -> "x = ${clean(-b / a)}" }
    }
    fun solveQuadratic(a: Double, b: Double, c: Double): String {
        require(a != 0.0) { "For a quadratic equation, a cannot be zero" }
        val d = b*b - 4*a*c
        return when {
            d > 0 -> "x₁ = ${clean((-b + sqrt(d))/(2*a))}\nx₂ = ${clean((-b - sqrt(d))/(2*a))}"
            d == 0.0 -> "Repeated root: x = ${clean(-b/(2*a))}"
            else -> "x₁ = ${clean(-b/(2*a))} + ${clean(sqrt(-d)/(2*a))}i\nx₂ = ${clean(-b/(2*a))} − ${clean(sqrt(-d)/(2*a))}i"
        }
    }
    fun statistics(input: String): StatisticsResult {
        val tokens = input.split(',', ';', '\n', ' ').map { it.trim() }.filter { it.isNotEmpty() }
        require(tokens.isNotEmpty()) { "Enter comma-separated numbers" }
        val xs = tokens.map { it.toDoubleOrNull() ?: throw IllegalArgumentException("Enter numbers only; invalid value: '$it'") }
        require(xs.all { it.isFinite() }) { "Numbers must be finite" }
        val sorted = xs.sorted(); val mean = xs.average(); val variance = xs.sumOf { (it - mean).pow(2) } / xs.size
        val counts = xs.groupingBy { it }.eachCount(); val maxCount = counts.values.maxOrNull() ?: 0
        val modes = if (maxCount <= 1) emptyList() else counts.filterValues { it == maxCount }.keys.sorted()
        val median = if (sorted.size % 2 == 1) sorted[sorted.size/2] else (sorted[sorted.size/2-1] + sorted[sorted.size/2]) / 2.0
        return StatisticsResult(xs.size, xs.sum(), mean, median, modes, sorted.first(), sorted.last(), sorted.last()-sorted.first(), variance, sqrt(variance))
    }
    fun parseMatrix(input: String): List<List<Double>> {
        val rows = input.trim().split(';', '\n').map { row -> row.trim().split(',', ' ').filter(String::isNotBlank).map { it.toDoubleOrNull() ?: throw IllegalArgumentException("Matrix values must be numbers") } }
        require(rows.isNotEmpty() && rows.first().isNotEmpty()) { "Enter a matrix, e.g. 1,2;3,4" }
        require(rows.size <= 3 && rows.all { it.size == rows.first().size } && rows.first().size <= 3) { "Use a rectangular matrix up to 3×3" }
        return rows
    }
    fun matrix(a: List<List<Double>>, b: List<List<Double>>?, op: String): String {
        val rows=a.size; val cols=a[0].size
        fun fmt(m: List<List<Double>>) = m.joinToString("\n") { row -> row.joinToString("   ") { clean(it) } }
        val result: List<List<Double>> = when(op) {
            "Transpose" -> (0 until cols).map { c -> (0 until rows).map { r -> a[r][c] } }
            "Determinant" -> { require(rows == cols) { "Determinant requires a square matrix" }; return clean(det(a)).toString() }
            "Inverse" -> { require(rows == cols) { "Inverse requires a square matrix" }; val d=det(a); require(abs(d)>1e-12) { "Matrix is singular and has no inverse" }; inverse(a) }
            "Add", "Subtract" -> { val bb=b ?: throw IllegalArgumentException("Enter matrix B"); require(rows==bb.size && cols==bb[0].size) { "Matrices must have the same dimensions" }; List(rows) { r -> List(cols) { c -> if(op=="Add") a[r][c]+bb[r][c] else a[r][c]-bb[r][c] } } }
            "Multiply" -> { val bb=b ?: throw IllegalArgumentException("Enter matrix B"); require(cols==bb.size) { "A columns must equal B rows" }; List(rows) { r -> List(bb[0].size) { c -> (0 until cols).sumOf { k -> a[r][k]*bb[k][c] } } } }
            else -> throw IllegalArgumentException("Choose an operation")
        }
        return fmt(result)
    }
    private fun det(a: List<List<Double>>): Double = when(a.size) {
        1 -> a[0][0]
        2 -> a[0][0]*a[1][1]-a[0][1]*a[1][0]
        3 -> a[0][0]*(a[1][1]*a[2][2]-a[1][2]*a[2][1])-a[0][1]*(a[1][0]*a[2][2]-a[1][2]*a[2][0])+a[0][2]*(a[1][0]*a[2][1]-a[1][1]*a[2][0])
        else -> throw IllegalArgumentException("Only square matrices up to 3×3 are supported")
    }
    private fun inverse(a: List<List<Double>>): List<List<Double>> {
        val n=a.size; val d=det(a)
        if(n==1) return listOf(listOf(1.0/d))
        if(n==2) return listOf(listOf(a[1][1]/d,-a[0][1]/d),listOf(-a[1][0]/d,a[0][0]/d))
        return List(3) { r -> List(3) { c ->
            val rows=(0..2).filter { it!=c }; val cols=(0..2).filter { it!=r }
            val minor=a[rows[0]][cols[0]]*a[rows[1]][cols[1]]-a[rows[0]][cols[1]]*a[rows[1]][cols[0]]
            (if((r+c)%2==0) 1 else -1)*minor/d
        } }
    }
    fun decimalToFraction(value: Double, maxDenominator: Long = 1_000_000L): String {
        require(value.isFinite()) { "Enter a finite number" }
        if (value == 0.0) return "0/1"
        val sign = if (value < 0) "-" else ""
        val x = abs(value)
        var h0 = 0L; var h1 = 1L; var k0 = 1L; var k1 = 0L; var y = x
        repeat(64) {
            val a = floor(y).toLong()
            val h2 = a * h1 + h0; val k2 = a * k1 + k0
            if (k2 > maxDenominator || h2 < 0) return@repeat
            h0 = h1; h1 = h2; k0 = k1; k1 = k2
            val frac = y - a
            if (frac < 1e-12) return "$sign$h1/$k1"
            y = 1.0 / frac
        }
        val g = gcdLong(h1, k1)
        return "$sign${h1/g}/${k1/g}"
    }
    fun fractionToDecimal(value: String): Double {
        val bits = value.trim().split('/')
        require(bits.size in 1..2) { "Enter a decimal or fraction such as 3/4" }
        val a = bits[0].toDoubleOrNull() ?: throw IllegalArgumentException("Invalid numerator")
        if (bits.size == 1) return a
        val b = bits[1].toDoubleOrNull() ?: throw IllegalArgumentException("Invalid denominator")
        require(b != 0.0) { "Denominator cannot be zero" }
        return a / b
    }
    private fun gcdLong(a: Long, b: Long): Long {
        var x = kotlin.math.abs(a); var y = kotlin.math.abs(b)
        while (y != 0L) { val t=x%y; x=y; y=t }
        return if (x == 0L) 1L else x
    }
    fun plot(expr: String, x: Double): Double = CalculatorEngine().evaluate(expr, degrees = false, variables = mapOf("x" to x))
    fun clean(v: Double): String = if (!v.isFinite()) "Error" else if (abs(v) < 1e-12) "0" else String.format(java.util.Locale.US, "%.8g", v)
}
