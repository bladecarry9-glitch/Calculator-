package com.smb.scientificcalculator.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class HistoryItem(
    val id: Long,
    val expression: String,
    val result: String,
    val timestamp: Long,
    val favorite: Boolean = false
)

data class AppSettings(
    val theme: String = "system",
    val degrees: Boolean = true,
    val decimals: Int = 10,
    val groupThousands: Boolean = false,
    val haptics: Boolean = true,
    val clickSound: Boolean = false,
    val time24h: Boolean = true,
    val autoClearHistory: Boolean = false
)

class LocalRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("science_calculator_pro", Context.MODE_PRIVATE)

    fun loadSettings(): AppSettings = AppSettings(
        theme = prefs.getString("theme", "system") ?: "system",
        degrees = prefs.getBoolean("degrees", true),
        decimals = prefs.getInt("decimals", 10).coerceIn(2, 14),
        groupThousands = prefs.getBoolean("groupThousands", false),
        haptics = prefs.getBoolean("haptics", true),
        clickSound = prefs.getBoolean("clickSound", false),
        time24h = prefs.getBoolean("time24h", true),
        autoClearHistory = prefs.getBoolean("autoClearHistory", false)
    )

    fun saveSettings(s: AppSettings) {
        prefs.edit().putString("theme", s.theme).putBoolean("degrees", s.degrees)
            .putInt("decimals", s.decimals.coerceIn(2, 14)).putBoolean("groupThousands", s.groupThousands)
            .putBoolean("haptics", s.haptics).putBoolean("clickSound", s.clickSound)
            .putBoolean("time24h", s.time24h).putBoolean("autoClearHistory", s.autoClearHistory).apply()
    }

    @Synchronized fun loadHistory(): List<HistoryItem> = runCatching {
        val json = JSONArray(prefs.getString("history", "[]") ?: "[]")
        (0 until json.length()).mapNotNull { i ->
            val o = json.optJSONObject(i) ?: return@mapNotNull null
            HistoryItem(o.optLong("id"), o.optString("expression"), o.optString("result"), o.optLong("timestamp"), o.optBoolean("favorite"))
        }.sortedByDescending { it.timestamp }
    }.getOrDefault(emptyList())

    @Synchronized fun saveHistory(items: List<HistoryItem>) {
        val arr = JSONArray()
        items.take(1000).forEach { item ->
            arr.put(JSONObject().put("id", item.id).put("expression", item.expression).put("result", item.result)
                .put("timestamp", item.timestamp).put("favorite", item.favorite))
        }
        prefs.edit().putString("history", arr.toString()).apply()
    }

    fun resetSettings() {
        prefs.edit().remove("theme").remove("degrees").remove("decimals").remove("groupThousands")
            .remove("haptics").remove("clickSound").remove("time24h").remove("autoClearHistory").apply()
    }
}
