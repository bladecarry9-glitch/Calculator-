package com.smb.scientificcalculator.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import com.smb.scientificcalculator.core.CalculatorEngine
import com.smb.scientificcalculator.core.formatNumber
import com.smb.scientificcalculator.data.AppSettings
import com.smb.scientificcalculator.data.HistoryItem
import com.smb.scientificcalculator.data.LocalRepository
import com.smb.scientificcalculator.ui.screens.*
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScienceCalculatorApp() {
    val context = LocalContext.current
    val repo = remember { LocalRepository(context) }
    val initialSettings = remember { repo.loadSettings() }
    var settings by remember { mutableStateOf(initialSettings) }
    var history by remember { mutableStateOf(if (initialSettings.autoClearHistory) emptyList() else repo.loadHistory()) }
    LaunchedEffect(Unit) { if (initialSettings.autoClearHistory) repo.saveHistory(emptyList()) }
    var selected by remember { mutableStateOf("Calculator") }
    var showSettings by remember { mutableStateOf(false) }
    var expression by remember { mutableStateOf("") }
    var answer by remember { mutableDoubleStateOf(0.0) }
    var answerText by remember { mutableStateOf("0") }
    var calculationError by remember { mutableStateOf<String?>(null) }
    var memoryValue by remember { mutableDoubleStateOf(0.0) }
    val toneGenerator = remember { runCatching { ToneGenerator(AudioManager.STREAM_SYSTEM, 25) }.getOrNull() }
    var historyFilter by remember { mutableStateOf("") }
    val engine = remember { CalculatorEngine() }
    val haptic = LocalHapticFeedback.current
    val dark = when (settings.theme) { "dark" -> true; "light" -> false; else -> isSystemInDarkTheme() }

    fun updateSettings(next: AppSettings) { settings = next; repo.saveSettings(next) }
    fun performKey(key: String) {
        calculationError = null
        if (settings.haptics) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        if (settings.clickSound) runCatching { toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 25) }
        when (key) {
            "AC" -> expression = ""
            "DEL" -> expression = expression.dropLast(1)
            "MC" -> memoryValue = 0.0
            "MR" -> expression += formatNumber(memoryValue, settings.decimals, false)
            "MS" -> runCatching { engine.evaluate(expression, settings.degrees, answer) }.onSuccess { memoryValue = it }
            "M+" -> runCatching { engine.evaluate(expression, settings.degrees, answer) }.onSuccess { memoryValue += it }
            "M-" -> runCatching { engine.evaluate(expression, settings.degrees, answer) }.onSuccess { memoryValue -= it }
            "NEG" -> if (expression.isNotBlank()) expression = if (expression.startsWith("-(") && expression.endsWith(")")) expression.removePrefix("-(").dropLast(1) else "-($expression)"
            "INV" -> if (expression.isNotBlank()) expression = "1/($expression)"
            "PASTE" -> {
                val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val copied = cb.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                if (!copied.isNullOrBlank()) expression += copied
            }
            "ANS" -> expression += "ans"
            else -> expression += key
        }
    }
    fun evaluateAndSave() {
        runCatching { engine.evaluate(expression, settings.degrees, answer) }
            .onSuccess { value ->
                calculationError = null
                answer = value
                answerText = formatNumber(value, settings.decimals, settings.groupThousands)
                val item = HistoryItem(System.currentTimeMillis(), expression, answerText, System.currentTimeMillis())
                history = (listOf(item) + history).take(1000)
                repo.saveHistory(history)
            }
            .onFailure { error -> calculationError = error.message ?: "Invalid expression" }
    }
    fun reuseHistory(item: HistoryItem) { expression = item.expression; answer = item.result.toDoubleOrNull() ?: answer; selected = "Calculator" }
    fun copyText(text: String) {
        val cb = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("Science Calculator Pro", text))
    }

    ScienceCalculatorTheme(darkTheme = dark) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            topBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface).padding(horizontal = 18.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Science Calculator Pro", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                        Text("Offline • Scientific tools", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .65f))
                    }
                    IconButton(onClick = { showSettings = true }) { Icon(Icons.Default.Settings, "Settings") }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 4.dp) {
                    val destinations = listOf(
                        Triple("Calculator", Icons.Default.Calculate, "Calc"),
                        Triple("Time", Icons.Default.Schedule, "Time"),
                        Triple("Converters", Icons.Default.SwapHoriz, "Convert"),
                        Triple("Advanced Math", Icons.Default.Functions, "Advanced"),
                        Triple("History", Icons.Default.History, "History")
                    )
                    destinations.forEach { (name, icon, label) ->
                        NavigationBarItem(selected = selected == name, onClick = { selected = name }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label, fontSize = 10.sp, maxLines = 1) }, alwaysShowLabel = true)
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (selected) {
                    "Calculator" -> CalculatorScreen(
                        expression = expression,
                        result = runCatching { engine.evaluate(expression, settings.degrees, answer) }.getOrNull(),
                        answerText = answerText,
                        calculationError = calculationError,
                        degrees = settings.degrees,
                        decimals = settings.decimals,
                        groupThousands = settings.groupThousands,
                        onKey = ::performKey,
                        onEquals = ::evaluateAndSave,
                        onToggleAngle = { updateSettings(settings.copy(degrees = !settings.degrees)) },
                        onCopy = { copyText(it) }
                    )
                    "Time" -> TimeScreen(time24h = settings.time24h)
                    "Converters" -> ConverterScreen()
                    "Advanced Math" -> AdvancedMathScreen(onCopy = ::copyText)
                    "History" -> HistoryScreen(
                        items = history,
                        filter = historyFilter,
                        onFilter = { historyFilter = it },
                        onReuse = ::reuseHistory,
                        onCopy = ::copyText,
                        onToggleFavorite = { item -> history = history.map { if (it.id == item.id) it.copy(favorite = !it.favorite) else it }; repo.saveHistory(history) },
                        onDelete = { item -> history = history.filterNot { it.id == item.id }; repo.saveHistory(history) },
                        onClear = { history = history.filter { it.favorite }; repo.saveHistory(history) }
                    )
                }
            }
        }
        if (showSettings) {
            SettingsDialog(settings = settings, onSettings = ::updateSettings, onClose = { showSettings = false }, onClearHistory = { history = emptyList(); repo.saveHistory(history) }, onReset = {
                repo.resetSettings(); settings = AppSettings(); repo.saveSettings(settings)
            })
        }
    }
}

@Composable
fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        if (subtitle != null) Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
    }
}

@Composable
fun SettingsDialog(settings: AppSettings, onSettings: (AppSettings) -> Unit, onClose: () -> Unit, onClearHistory: () -> Unit, onReset: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Settings", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 520.dp).padding(bottom = 4.dp).verticalScroll(androidx.compose.foundation.rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Appearance", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("system" to "System", "light" to "Light", "dark" to "Dark").forEach { (v, l) ->
                        FilterChip(selected = settings.theme == v, onClick = { onSettings(settings.copy(theme = v)) }, label = { Text(l) })
                    }
                }
                SettingSwitch("Thousands separators", settings.groupThousands) { onSettings(settings.copy(groupThousands = it)) }
                Text("Decimal precision: ${settings.decimals}")
                Slider(value = settings.decimals.toFloat(), onValueChange = { onSettings(settings.copy(decimals = it.toInt().coerceIn(2, 14))) }, valueRange = 2f..14f, steps = 11)
                SettingSwitch("Haptic feedback", settings.haptics) { onSettings(settings.copy(haptics = it)) }
                SettingSwitch("Button click sound", settings.clickSound) { onSettings(settings.copy(clickSound = it)) }
                SettingSwitch("24-hour time format", settings.time24h) { onSettings(settings.copy(time24h = it)) }
                SettingSwitch("Automatically clear history on launch", settings.autoClearHistory) { onSettings(settings.copy(autoClearHistory = it)) }
                Text("About", fontWeight = FontWeight.SemiBold)
                Text("Science Calculator Pro 1.0.0\nOffline calculator • Package: com.smb.scientificcalculator", fontSize = 12.sp)
                OutlinedButton(onClick = onClearHistory, modifier = Modifier.fillMaxWidth()) { Text("Clear calculation history") }
                TextButton(onClick = onReset, modifier = Modifier.fillMaxWidth()) { Text("Restore default settings") }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Done") } }
    )
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
