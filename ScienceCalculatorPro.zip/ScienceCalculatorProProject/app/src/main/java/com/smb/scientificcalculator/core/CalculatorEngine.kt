package com.smb.scientificcalculator.core

import kotlin.math.*

/** A small recursive-descent math parser. It never executes user input as code. */
class CalculatorEngine {
    fun evaluate(
        input: String,
        degrees: Boolean = true,
        ans: Double = 0.0,
        variables: Map<String, Double> = emptyMap()
    ): Double {
        if (input.isBlank()) throw IllegalArgumentException("Enter an expression")
        val parser = Parser(input, degrees, ans, variables)
        val value = parser.parse()
        if (!value.isFinite()) throw ArithmeticException("Result is undefined or out of range")
        return value
    }

    private class Parser(
        private val source: String,
        private val degrees: Boolean,
        private val ans: Double,
        private val variables: Map<String, Double>
    ) {
        private var pos = 0
        private fun skipSpaces() { while (pos < source.length && source[pos].isWhitespace()) pos++ }
        private fun eat(c: Char): Boolean {
            skipSpaces()
            if (pos < source.length && source[pos] == c) { pos++; return true }
            return false
        }
        private fun requireEat(c: Char) { if (!eat(c)) fail("Expected '$c'") }
        private fun fail(message: String): Nothing = throw IllegalArgumentException("$message at position ${pos + 1}")
        fun parse(): Double {
            val value = expression()
            skipSpaces()
            if (pos != source.length) fail("Unexpected '${source[pos]}'")
            return value
        }
        private fun expression(): Double {
            var v = term()
            while (true) {
                v = when {
                    eat('+') -> v + term()
                    eat('-') -> v - term()
                    else -> return v
                }
            }
        }
        private fun term(): Double {
            var v = unary()
            while (true) {
                v = when {
                    eat('*') || eat('×') -> v * unary()
                    eat('/') || eat('÷') -> {
                        val d = unary(); if (d == 0.0) throw ArithmeticException("Cannot divide by zero"); v / d
                    }
                    else -> return v
                }
            }
        }
        private fun unary(): Double {
            return when {
                eat('+') -> unary()
                eat('-') -> -unary()
                else -> power()
            }
        }
        private fun power(): Double {
            var v = postfix()
            if (eat('^')) v = v.pow(unary())
            if (!v.isFinite()) throw ArithmeticException("Invalid power or numeric overflow")
            return v
        }
        private fun postfix(): Double {
            var v = primary()
            while (true) {
                when {
                    eat('!') -> v = factorial(v)
                    eat('%') -> v /= 100.0
                    else -> return v
                }
            }
        }
        private fun primary(): Double {
            skipSpaces()
            if (eat('(')) {
                val v = expression(); requireEat(')'); return v
            }
            if (pos >= source.length) fail("Unexpected end of expression")
            val c = source[pos]
            if (c.isDigit() || c == '.') return number()
            if (c.isLetter() || c == 'π' || c == '√') {
                val name = identifier()
                if (name == "sqrtSymbol") return sqrt(unary())
                skipSpaces()
                if (eat('(')) {
                    val args = mutableListOf<Double>()
                    if (!eat(')')) {
                        do { args += expression() } while (eat(','))
                        requireEat(')')
                    }
                    return call(name.lowercase(), args)
                }
                return when (name.lowercase()) {
                    "pi", "π" -> Math.PI
                    "e" -> Math.E
                    "ans" -> ans
                    else -> variables[name] ?: variables[name.lowercase()] ?: fail("Unknown value '$name'")
                }
            }
            fail("Unexpected '${source[pos]}'")
        }
        private fun number(): Double {
            skipSpaces(); val start = pos
            var sawDigit = false
            while (pos < source.length && source[pos].isDigit()) { pos++; sawDigit = true }
            if (pos < source.length && source[pos] == '.') {
                pos++
                while (pos < source.length && source[pos].isDigit()) { pos++; sawDigit = true }
            }
            if (!sawDigit) fail("Invalid number")
            if (pos < source.length && (source[pos] == 'e' || source[pos] == 'E')) {
                val exponentStart = pos; var j = pos + 1
                if (j < source.length && (source[j] == '+' || source[j] == '-')) j++
                val digitsStart = j
                while (j < source.length && source[j].isDigit()) j++
                if (j > digitsStart) pos = j else pos = exponentStart
            }
            return source.substring(start, pos).toDoubleOrNull() ?: fail("Invalid number")
        }
        private fun identifier(): String {
            if (source[pos] == 'π') { pos++; return "π" }
            if (source[pos] == '√') { pos++; return "sqrtSymbol" }
            val start = pos
            while (pos < source.length && (source[pos].isLetterOrDigit() || source[pos] == '_')) pos++
            if (pos == start) fail("Expected a value")
            return source.substring(start, pos)
        }
        private fun call(name: String, a: List<Double>): Double {
            fun one() = a.singleOrNull() ?: fail("$name expects one argument")
            fun two() = if (a.size == 2) Pair(a[0], a[1]) else fail("$name expects two arguments")
            fun angle(x: Double) = if (degrees) Math.toRadians(x) else x
            fun outAngle(x: Double) = if (degrees) Math.toDegrees(x) else x
            return when (name) {
                "sin" -> sin(angle(one()))
                "cos" -> cos(angle(one()))
                "tan" -> tan(angle(one()))
                "asin", "arcsin" -> outAngle(asin(one()))
                "acos", "arccos" -> outAngle(acos(one()))
                "atan", "arctan" -> outAngle(atan(one()))
                "sinh" -> sinh(one())
                "cosh" -> cosh(one())
                "tanh" -> tanh(one())
                "asinh" -> ln(one() + sqrt(one() * one() + 1.0))
                "acosh" -> { val x = one(); if (x < 1) fail("acosh domain is x ≥ 1"); ln(x + sqrt(x*x-1)) }
                "atanh" -> { val x = one(); if (abs(x) >= 1) fail("atanh domain is -1 < x < 1"); 0.5 * ln((1+x)/(1-x)) }
                "sqrt" -> { val x = one(); if (x < 0) fail("Square root requires a non-negative value"); sqrt(x) }
                "cbrt" -> cbrt(one())
                "abs" -> abs(one())
                "floor" -> floor(one())
                "ceil", "ceiling" -> ceil(one())
                "round" -> if (a.size == 1) round(a[0]) else if (a.size == 2 && a[1] % 1.0 == 0.0 && a[1] in -12.0..12.0) {
                    val scale = 10.0.pow(a[1]); round(a[0] * scale) / scale
                } else fail("round expects x or x, decimalPlaces")
                "ln" -> ln(one()).also { if (!it.isFinite()) fail("ln domain is x > 0") }
                "log", "log10" -> log10(one()).also { if (!it.isFinite()) fail("log domain is x > 0") }
                "exp" -> exp(one())
                "fact", "factorial" -> factorial(one())
                "logb" -> { val (x,b)=two(); if (x <= 0 || b <= 0 || b == 1.0) fail("logb requires x > 0, base > 0 and base ≠ 1"); ln(x)/ln(b) }
                "root" -> { val (x,n)=two(); if (n == 0.0) fail("Root index cannot be zero"); if (x < 0 && n % 2.0 != 0.0) -((-x).pow(1.0/n)) else if (x < 0) fail("Even root of a negative number is not real") else x.pow(1.0/n) }
                "pctchange" -> { val (old,new)=two(); if (old == 0.0) fail("Percentage change is undefined when the original value is zero"); (new-old)/abs(old)*100.0 }
                "sig" -> { val (x,n)=two(); if (n !in 1.0..15.0 || n % 1.0 != 0.0) fail("sig(x,n) requires n from 1 to 15"); java.math.BigDecimal.valueOf(x).round(java.math.MathContext(n.toInt(), java.math.RoundingMode.HALF_UP)).toDouble() }
                "rand", "random" -> when (a.size) { 0 -> kotlin.random.Random.nextDouble(); 2 -> { val (lo,hi)=two(); if (hi < lo) fail("random upper bound must be ≥ lower bound"); lo + kotlin.random.Random.nextDouble()*(hi-lo) }; else -> fail("rand() or random(min,max)") }
                "mod" -> { val (x,y)=two(); if (y == 0.0) fail("Modulo by zero"); x % y }
                "npr" -> { val (n,r)=two(); factorial(n)/factorial(n-r) }
                "ncr" -> { val (n,r)=two(); if (r < 0 || r > n) fail("nCr requires 0 ≤ r ≤ n"); factorial(n)/(factorial(r)*factorial(n-r)) }
                "gcd" -> { val (x,y)=two(); gcdInt(x,y).toDouble() }
                "lcm" -> { val (x,y)=two(); val gx=gcdInt(x,y); if (gx == 0L) 0.0 else abs((x.toLong()/gx)*y.toLong()).toDouble() }
                "min" -> a.minOrNull() ?: fail("min needs arguments")
                "max" -> a.maxOrNull() ?: fail("max needs arguments")
                else -> fail("Unknown function '$name'")
            }
        }
        private fun factorial(v: Double): Double {
            if (!v.isFinite() || v < 0 || v > 170 || v % 1.0 != 0.0) fail("Factorial requires an integer from 0 to 170")
            var result = 1.0
            for (i in 2..v.toInt()) result *= i
            return result
        }
        private fun gcdInt(a: Double, b: Double): Long {
            if (!a.isFinite() || !b.isFinite() || a % 1.0 != 0.0 || b % 1.0 != 0.0 || abs(a) > Long.MAX_VALUE || abs(b) > Long.MAX_VALUE) fail("GCD/LCM require whole numbers")
            var x = abs(a.toLong()); var y = abs(b.toLong())
            while (y != 0L) { val t=x%y; x=y; y=t }
            return x
        }
    }
}

fun formatNumber(value: Double, decimals: Int = 10, groupThousands: Boolean = false): String {
    if (!value.isFinite()) return "Error"
    val precision = decimals.coerceIn(0, 14)
    val magnitude = kotlin.math.abs(value)
    val raw = if (magnitude >= 1.0e15 || (magnitude > 0.0 && magnitude < 1.0e-9)) {
        String.format(java.util.Locale.US, "%." + precision + "g", value)
    } else {
        java.math.BigDecimal.valueOf(value).setScale(precision, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
    }
    if (!groupThousands || raw.contains('E') || raw.contains('e')) return raw
    val pieces = raw.split('.')
    val sign = if (pieces[0].startsWith("-")) "-" else ""
    val digits = pieces[0].removePrefix("-").reversed().chunked(3).joinToString(",").reversed()
    return sign + digits + if (pieces.size > 1) ".${pieces[1]}" else ""
}
