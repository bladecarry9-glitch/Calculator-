package com.smb.scientificcalculator.ui.screens

import com.smb.scientificcalculator.ui.SectionTitle

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smb.scientificcalculator.data.HistoryItem
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    items: List<HistoryItem>, filter: String, onFilter: (String) -> Unit, onReuse: (HistoryItem) -> Unit,
    onCopy: (String) -> Unit, onToggleFavorite: (HistoryItem) -> Unit, onDelete: (HistoryItem) -> Unit, onClear: () -> Unit
) {
    val visible = items.filter { it.expression.contains(filter, true) || it.result.contains(filter, true) }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { SectionTitle("Calculation history", "Saved locally on this device") }
            TextButton(onClick = onClear, enabled = items.isNotEmpty()) { Text("Clear non-favourites") }
        }
        OutlinedTextField(value = filter, onValueChange = onFilter, modifier = Modifier.fillMaxWidth(), label = { Text("Search history") }, singleLine = true, shape = RoundedCornerShape(14.dp))
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) { Text(if (items.isEmpty()) "Your calculations will appear here." else "No matching calculations.", color = MaterialTheme.colorScheme.onBackground.copy(alpha=.65f)) }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 8.dp)) {
                items(visible, key = { it.id }) { item ->
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                        Column(Modifier.fillMaxWidth().clickable { onReuse(item) }.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.expression.ifBlank { "(empty expression)" }, modifier = Modifier.weight(1f), fontSize = 14.sp, maxLines = 2)
                                IconButton(onClick = { onToggleFavorite(item) }, modifier = Modifier.size(34.dp)) { Icon(if (item.favorite) Icons.Default.Star else Icons.Outlined.StarOutline, if (item.favorite) "Remove favorite" else "Add favorite", tint = if (item.favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) }
                            }
                            Text("= ${item.result}", fontSize = 21.sp, color = MaterialTheme.colorScheme.primary)
                            Text(SimpleDateFormat("yyyy-MM-dd • HH:mm:ss", Locale.getDefault()).format(Date(item.timestamp)), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.6f))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = { onCopy(item.result) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.ContentCopy, "Copy result") }
                                IconButton(onClick = { onDelete(item) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.Delete, "Delete history item") }
                            }
                        }
                    }
                }
            }
        }
    }
}
