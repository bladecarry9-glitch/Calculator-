package com.smb.scientificcalculator.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smb.scientificcalculator.core.formatNumber

private data class CalcButton(val label: String, val token: String = label, val kind: Int = 0)

@Composable
fun CalculatorScreen(
    expression: String,
    result: Double?,
    answerText: String,
    calculationError: String?,
    degrees: Boolean,
    decimals: Int,
    groupThousands: Boolean,
    onKey: (String) -> Unit,
    onEquals: () -> Unit,
    onToggleAngle: () -> Unit,
    onCopy: (String) -> Unit
) {
    val keys = listOf(
        CalcButton(if (degrees) "DEG" else "RAD", "ANGLE", 2), CalcButton("AC", "AC", 2), CalcButton("DEL", "DEL", 2), CalcButton("(", "("), CalcButton(")", ")"),
        CalcButton("MC", "MC", 1), CalcButton("MR", "MR", 1), CalcButton("M+", "M+", 1), CalcButton("M−", "M-", 1), CalcButton("MS", "MS", 1),
        CalcButton("sin", "sin(", 1), CalcButton("cos", "cos(", 1), CalcButton("tan", "tan(", 1), CalcButton("ln", "ln(", 1), CalcButton("log", "log(" ,1),
        CalcButton("√", "sqrt(", 1), CalcButton("xʸ", "^", 1), CalcButton("x²", "^2", 1), CalcButton("x³", "^3", 1), CalcButton("x!", "!", 1),
        CalcButton("root", "root(", 1), CalcButton("cbrt", "cbrt(", 1), CalcButton("mod", "mod(", 1), CalcButton("rand", "rand()", 1), CalcButton("%Δ", "pctchange(", 1),
        CalcButton(",", ",", 2), CalcButton("nCr", "ncr(", 1), CalcButton("nPr", "npr(", 1), CalcButton("logᵦ", "logb(", 1), CalcButton("round", "round(", 1),
        CalcButton("7"), CalcButton("8"), CalcButton("9"), CalcButton("÷", "/", 2), CalcButton("Ans", "ANS", 1),
        CalcButton("4"), CalcButton("5"), CalcButton("6"), CalcButton("×", "*", 2), CalcButton("π", "pi", 1),
        CalcButton("1"), CalcButton("2"), CalcButton("3"), CalcButton("−", "-", 2), CalcButton("e", "e", 1),
        CalcButton("±", "NEG", 1), CalcButton("0"), CalcButton("."), CalcButton("+", "+", 2), CalcButton("%", "%", 1),
        CalcButton("sin⁻¹", "asin(", 1), CalcButton("cos⁻¹", "acos(", 1), CalcButton("tan⁻¹", "atan(", 1), CalcButton("1/x", "INV", 1), CalcButton("=", "=", 3)
    )
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Text(if (expression.isBlank()) "Enter calculation" else expression, modifier = Modifier.weight(1f), textAlign = TextAlign.End, maxLines = 2, overflow = TextOverflow.Ellipsis, fontSize = 20.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = .72f))
                    IconButton(onClick = { onCopy(if (result != null) formatNumber(result, decimals, groupThousands) else expression) }, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.ContentCopy, "Copy expression or result") }
                    IconButton(onClick = { onKey("PASTE") }, modifier = Modifier.size(36.dp)) { Icon(Icons.Default.ContentPaste, "Paste from clipboard") }
                }
                Spacer(Modifier.height(7.dp))
                Text(
                    text = when { calculationError != null -> "Error"; expression.isBlank() -> answerText; result == null -> "—"; else -> formatNumber(result, decimals, groupThousands) },
                    fontSize = 34.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (calculationError != null) Text(calculationError, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, textAlign = TextAlign.End)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Scientific", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .7f))
            TextButton(onClick = onToggleAngle) { Text(if (degrees) "Degrees (DEG)" else "Radians (RAD)") }
        }
        LazyVerticalGrid(
            columns = GridCells.Fixed(5), modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(bottom = 3.dp)
        ) {
            items(keys) { key ->
                val colors = when (key.kind) {
                    1 -> ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondaryContainer, contentColor = MaterialTheme.colorScheme.onSecondaryContainer)
                    2 -> ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant, contentColor = MaterialTheme.colorScheme.onSurface)
                    3 -> ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
                    else -> ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
                }
                Button(
                    onClick = {
                        when (key.token) {
                            "ANGLE" -> onToggleAngle()
                            "=" -> onEquals()
                            else -> onKey(key.token)
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(45.dp), shape = RoundedCornerShape(13.dp),
                    colors = colors, contentPadding = PaddingValues(horizontal = 2.dp, vertical = 0.dp)
                ) {
                    if (key.token == "DEL") Icon(Icons.Default.Backspace, contentDescription = "Delete last character", modifier = Modifier.size(18.dp))
                    else Text(key.label, fontWeight = if (key.kind == 3) FontWeight.Bold else FontWeight.Medium, fontSize = if (key.label.length > 5) 11.sp else 15.sp, maxLines = 1)
                }
            }
        }
    }
}
