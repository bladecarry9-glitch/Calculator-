package com.smb.scientificcalculator.time

import java.util.Locale

object TimeEngine {
    fun toSeconds(hours: Long, minutes: Long, seconds: Long): Long = hours * 3600L + minutes * 60L + seconds
    fun formatDuration(totalSeconds: Long): String {
        val sign = if (totalSeconds < 0) "−" else ""
        val absValue = kotlin.math.abs(totalSeconds)
        val h = absValue / 3600
        val m = (absValue % 3600) / 60
        val s = absValue % 60
        return "$sign${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}"
    }
    fun parseClock(text: String): Int {
        val normalized = text.trim().uppercase(Locale.US)
        val am = normalized.endsWith(" AM")
        val pm = normalized.endsWith(" PM")
        val cleaned = if (am || pm) normalized.dropLast(3).trim() else normalized
        val pieces = cleaned.split(":")
        require(pieces.size in 2..3) { "Use HH:MM, HH:MM:SS or 12-hour time with AM/PM" }
        var h = pieces[0].toIntOrNull() ?: throw IllegalArgumentException("Invalid hours")
        val m = pieces[1].toIntOrNull() ?: throw IllegalArgumentException("Invalid minutes")
        val s = if (pieces.size == 3) pieces[2].toIntOrNull() ?: throw IllegalArgumentException("Invalid seconds") else 0
        if (am || pm) {
            require(h in 1..12) { "For AM/PM time, hours must be from 1 to 12" }
            h = (h % 12) + if (pm) 12 else 0
        }
        require(h in 0..23 && m in 0..59 && s in 0..59) { "Time is out of range" }
        return h * 3600 + m * 60 + s
    }
    fun clockDifference(start: String, end: String, crossesMidnight: Boolean = true): Long {
        val a = parseClock(start); val b = parseClock(end)
        var d = b - a
        if (crossesMidnight && d < 0) d += 24 * 3600
        return d.toLong()
    }
    fun formatClock(seconds: Long, use24Hour: Boolean = true): String {
        val normalized = ((seconds % 86400L) + 86400L) % 86400L
        val h = (normalized / 3600).toInt(); val m = ((normalized % 3600) / 60).toInt(); val s = (normalized % 60).toInt()
        return if (use24Hour) String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d:%02d %s", ((h + 11) % 12) + 1, m, s, if (h < 12) "AM" else "PM")
    }
}
