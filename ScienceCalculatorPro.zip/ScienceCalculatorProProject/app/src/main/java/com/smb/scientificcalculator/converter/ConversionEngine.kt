package com.smb.scientificcalculator.converter

import kotlin.math.PI

data class UnitDef(val label: String, val factor: Double)
object ConversionEngine {
    val categories = listOf("Length", "Weight", "Area", "Volume", "Speed", "Temperature", "Energy", "Pressure", "Data storage", "Angle", "Frequency", "Time")
    private val definitions: Map<String, Map<String, UnitDef>> = mapOf(
        "Length" to linkedMapOf("Millimeter" to UnitDef("mm", .001), "Centimeter" to UnitDef("cm", .01), "Meter" to UnitDef("m", 1.0), "Kilometer" to UnitDef("km", 1000.0), "Inch" to UnitDef("in", .0254), "Foot" to UnitDef("ft", .3048), "Yard" to UnitDef("yd", .9144), "Mile" to UnitDef("mi", 1609.344)),
        "Weight" to linkedMapOf("Milligram" to UnitDef("mg", .000001), "Gram" to UnitDef("g", .001), "Kilogram" to UnitDef("kg", 1.0), "Ounce" to UnitDef("oz", .028349523125), "Pound" to UnitDef("lb", .45359237)),
        "Area" to linkedMapOf("Square meter" to UnitDef("m²", 1.0), "Square kilometer" to UnitDef("km²", 1e6), "Square foot" to UnitDef("ft²", .09290304), "Acre" to UnitDef("acre", 4046.8564224)),
        "Volume" to linkedMapOf("Milliliter" to UnitDef("mL", .001), "Liter" to UnitDef("L", 1.0), "Cubic meter" to UnitDef("m³", 1000.0), "US gallon" to UnitDef("US gal", 3.785411784)),
        "Speed" to linkedMapOf("Meters/second" to UnitDef("m/s", 1.0), "Kilometers/hour" to UnitDef("km/h", 1.0/3.6), "Miles/hour" to UnitDef("mph", .44704)),
        "Energy" to linkedMapOf("Joule" to UnitDef("J", 1.0), "Kilojoule" to UnitDef("kJ", 1000.0), "Calorie" to UnitDef("cal", 4.184), "Kilowatt-hour" to UnitDef("kWh", 3600000.0)),
        "Pressure" to linkedMapOf("Pascal" to UnitDef("Pa", 1.0), "Kilopascal" to UnitDef("kPa", 1000.0), "Bar" to UnitDef("bar", 100000.0), "Atmosphere" to UnitDef("atm", 101325.0)),
        "Data storage" to linkedMapOf("Bit" to UnitDef("bit", .125), "Byte" to UnitDef("byte", 1.0), "KB" to UnitDef("KB", 1000.0), "MB" to UnitDef("MB", 1e6), "GB" to UnitDef("GB", 1e9), "TB" to UnitDef("TB", 1e12)),
        "Angle" to linkedMapOf("Degree" to UnitDef("°", PI/180.0), "Radian" to UnitDef("rad", 1.0)),
        "Frequency" to linkedMapOf("Hertz" to UnitDef("Hz", 1.0), "Kilohertz" to UnitDef("kHz", 1e3), "Megahertz" to UnitDef("MHz", 1e6), "Gigahertz" to UnitDef("GHz", 1e9)),
        "Time" to linkedMapOf("Millisecond" to UnitDef("ms", .001), "Second" to UnitDef("s", 1.0), "Minute" to UnitDef("min", 60.0), "Hour" to UnitDef("h", 3600.0), "Day" to UnitDef("day", 86400.0), "Week" to UnitDef("week", 604800.0))
    )
    fun units(category: String): List<String> = if (category == "Temperature") listOf("Celsius", "Fahrenheit", "Kelvin") else definitions[category]?.keys?.toList() ?: emptyList()
    fun convert(value: Double, category: String, from: String, to: String): Double {
        require(value.isFinite()) { "Enter a valid number" }
        if (category == "Temperature") {
            val c = when (from) { "Celsius" -> value; "Fahrenheit" -> (value - 32) * 5.0 / 9.0; "Kelvin" -> value - 273.15; else -> error("Unknown temperature unit") }
            if (c < -273.15 - 1e-9) throw IllegalArgumentException("Temperature cannot be below absolute zero")
            val result = when (to) { "Celsius" -> c; "Fahrenheit" -> c * 9.0 / 5.0 + 32; "Kelvin" -> c + 273.15; else -> error("Unknown temperature unit") }
            if (to == "Kelvin" && result < 0) throw IllegalArgumentException("Temperature cannot be below absolute zero")
            return result
        }
        val map = definitions[category] ?: throw IllegalArgumentException("Unknown category")
        val a = map[from] ?: throw IllegalArgumentException("Choose a source unit")
        val b = map[to] ?: throw IllegalArgumentException("Choose a target unit")
        return value * a.factor / b.factor
    }
}
