package com.smb.scientificcalculator.ui.screens

import com.smb.scientificcalculator.ui.SectionTitle

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.smb.scientificcalculator.converter.ConversionEngine
import java.util.Locale

@Composable
fun ConverterScreen() {
    var category by remember { mutableStateOf("Length") }
    var value by remember { mutableStateOf("1") }
    var from by remember { mutableStateOf("Meter") }
    var to by remember { mutableStateOf("Kilometer") }
    val units = ConversionEngine.units(category)
    LaunchedEffect(category) {
        val now = ConversionEngine.units(category)
        from = now.firstOrNull() ?: ""
        to = now.getOrElse(1) { now.firstOrNull() ?: "" }
    }
    val result = runCatching {
        ConversionEngine.convert(value.toDouble(), category, from, to)
    }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        SectionTitle("Unit converter", "Instant, offline conversions across 12 categories")
        ChoiceMenu("Category", category, ConversionEngine.categories, { category = it }, Modifier.fillMaxWidth())
        NumberField("Value to convert", value, { value = it }, Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            ChoiceMenu("From", from, units, { from = it }, Modifier.weight(1f))
            IconButton(onClick = { val tmp = from; from = to; to = tmp }) { Icon(Icons.Default.SwapHoriz, "Swap units") }
            ChoiceMenu("To", to, units, { to = it }, Modifier.weight(1f))
        }
        val output = result.getOrNull()
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(18.dp)) {
                Text("Result", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .75f))
                Spacer(Modifier.height(6.dp))
                Text(output?.let { String.format(Locale.US, "%.12g", it) } ?: result.exceptionOrNull()?.message ?: "Enter a number", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(to, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .8f))
            }
        }
        Text("Available: ${units.joinToString(", ")}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .7f))
        Text("Data storage uses decimal units (1 KB = 1,000 bytes). Angle conversion uses exact radians per degree.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .6f))
    }
}
