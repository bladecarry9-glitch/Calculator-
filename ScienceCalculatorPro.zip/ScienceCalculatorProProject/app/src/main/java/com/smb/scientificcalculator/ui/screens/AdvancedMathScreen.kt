package com.smb.scientificcalculator.ui.screens

import com.smb.scientificcalculator.ui.SectionTitle

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.smb.scientificcalculator.advanced.AdvancedMath
import kotlin.math.abs

@Composable
fun AdvancedMathScreen(onCopy: (String) -> Unit) {
    var mode by remember { mutableStateOf("Equation") }
    val modes = listOf("Equation", "Statistics", "Matrix", "Graph", "Fraction", "Constants")
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("Advanced mathematics", "Equation solving, statistics, matrices and graphs")
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            modes.forEach { FilterChip(selected = mode == it, onClick = { mode = it }, label = { Text(it, fontSize = 12.sp) }) }
        }
        when (mode) {
            "Equation" -> EquationTool()
            "Statistics" -> StatisticsTool()
            "Matrix" -> MatrixTool()
            "Graph" -> GraphTool()
            "Fraction" -> FractionTool()
            "Constants" -> ConstantsTool(onCopy)
        }
    }
}

@Composable
private fun EquationTool() {
    var type by remember { mutableStateOf("Quadratic") }
    var a by remember { mutableStateOf("1") }; var b by remember { mutableStateOf("-3") }; var c by remember { mutableStateOf("2") }
    val result = runCatching {
        val aa = a.toDouble(); val bb = b.toDouble(); val cc = c.toDouble()
        if (type == "Linear") "Equation: ${a}x + ${b} = 0\n${AdvancedMath.solveLinear(aa, bb)}" else "Equation: ${a}x² + ${b}x + ${c} = 0\n${AdvancedMath.solveQuadratic(aa, bb, cc)}"
    }.getOrElse { it.message ?: "Enter valid coefficients" }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Linear", "Quadratic").forEach { FilterChip(selected = type == it, onClick = { type = it }, label = { Text(it) }) }
        }
        Text(if (type == "Linear") "Solve ax + b = 0" else "Solve ax² + bx + c = 0", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NumberField("a", a, { a = it }, Modifier.weight(1f))
            NumberField("b", b, { b = it }, Modifier.weight(1f))
            if (type == "Quadratic") NumberField("c", c, { c = it }, Modifier.weight(1f))
        }
        ResultCard(result)
        Text("The quadratic solver reports real roots or complex conjugate roots when the discriminant is negative.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = .65f))
    }
}

@Composable
private fun StatisticsTool() {
    var data by remember { mutableStateOf("1, 2, 2, 4, 8") }
    val stats = runCatching { AdvancedMath.statistics(data) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        NumberField("Data (comma or space separated)", data, { data = it }, Modifier.fillMaxWidth(), singleLine = false)
        val s = stats.getOrNull()
        if (s == null) ResultCard(stats.exceptionOrNull()?.message ?: "Enter data") else {
            ResultCard("Count: ${s.count}\nSum: ${AdvancedMath.clean(s.sum)}\nMean: ${AdvancedMath.clean(s.mean)}\nMedian: ${AdvancedMath.clean(s.median)}\nMode: ${if (s.modes.isEmpty()) "No repeated mode" else s.modes.joinToString { AdvancedMath.clean(it) }}\nMinimum: ${AdvancedMath.clean(s.min)}\nMaximum: ${AdvancedMath.clean(s.max)}\nRange: ${AdvancedMath.clean(s.range)}\nPopulation variance: ${AdvancedMath.clean(s.variance)}\nPopulation standard deviation: ${AdvancedMath.clean(s.stdDev)}")
        }
    }
}

@Composable
private fun MatrixTool() {
    var inputA by remember { mutableStateOf("1,2;3,4") }; var inputB by remember { mutableStateOf("5,6;7,8") }; var op by remember { mutableStateOf("Add") }
    val ops = listOf("Add", "Subtract", "Multiply", "Transpose", "Determinant", "Inverse")
    val result = runCatching { AdvancedMath.matrix(AdvancedMath.parseMatrix(inputA), if (op in listOf("Add", "Subtract", "Multiply")) AdvancedMath.parseMatrix(inputB) else null, op) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Enter rows separated by semicolons and values by commas", style = MaterialTheme.typography.bodySmall)
        NumberField("Matrix A", inputA, { inputA = it }, Modifier.fillMaxWidth(), singleLine = false)
        if (op in listOf("Add", "Subtract", "Multiply")) NumberField("Matrix B", inputB, { inputB = it }, Modifier.fillMaxWidth(), singleLine = false)
        ChoiceMenu("Operation", op, ops, { op = it }, Modifier.fillMaxWidth())
        ResultCard(result.getOrNull() ?: (result.exceptionOrNull()?.message ?: "Invalid matrix"))
    }
}

@Composable
private fun GraphTool() {
    var expr by remember { mutableStateOf("sin(x)") }
    var range by remember { mutableFloatStateOf(10f) }
    var panX by remember { mutableFloatStateOf(0f) }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        NumberField("Function y =", expr, { expr = it }, Modifier.fillMaxWidth())
        Text("x-range: ±${range.toInt()} • Drag the plot to pan", style = MaterialTheme.typography.bodySmall)
        Slider(value = range, onValueChange = { range = it }, valueRange = 2f..30f, steps = 13)
        val graphColor = MaterialTheme.colorScheme.primary
        Canvas(Modifier.fillMaxWidth().weight(1f).pointerInput(range) {
            detectDragGestures { change, drag -> change.consume(); panX -= drag.x / size.width * range * 2f }
        }) {
            val w=size.width; val h=size.height
            val stepX=w/10f; val stepY=h/10f
            for(i in 0..10) {
                val x=i*stepX; val y=i*stepY
                drawLine(Color.Gray.copy(alpha=.20f), Offset(x,0f), Offset(x,h), 1.dp.toPx())
                drawLine(Color.Gray.copy(alpha=.20f), Offset(0f,y), Offset(w,y), 1.dp.toPx())
            }
            drawLine(Color.Gray, Offset(w/2f,0f), Offset(w/2f,h), 1.dp.toPx())
            drawLine(Color.Gray, Offset(0f,h/2f), Offset(w,h/2f), 1.dp.toPx())
            val path=Path(); var started=false
            for(i in 0..(w.toInt().coerceAtLeast(1))) {
                val px=i.toFloat(); val x=((px/w)*2-1)*range + panX
                val y=runCatching { AdvancedMath.plot(expr, x) }.getOrNull()
                if(y==null || !y.isFinite() || abs(y)>range*4) { started=false; continue }
                val py=h/2f - (y/range)*(h/2f)
                if(!started) { path.moveTo(px,py); started=true } else path.lineTo(px,py)
            }
            drawPath(path, graphColor, style=Stroke(width=2.dp.toPx(), cap=StrokeCap.Round))
        }
        OutlinedButton(onClick = { panX = 0f }, modifier = Modifier.fillMaxWidth()) { Text("Reset pan") }
    }
}

@Composable
private fun ConstantsTool(onCopy: (String) -> Unit) {
    val constants = listOf(
        "Pi (π)" to "3.141592653589793", "Euler's number (e)" to "2.718281828459045", "Speed of light (c)" to "299792458 m/s",
        "Gravitational constant (G)" to "6.67430 × 10⁻¹¹ m³ kg⁻¹ s⁻²", "Planck constant (h)" to "6.62607015 × 10⁻³⁴ J·s",
        "Avogadro constant (Nₐ)" to "6.02214076 × 10²³ mol⁻¹", "Elementary charge (e)" to "1.602176634 × 10⁻¹⁹ C",
        "Gas constant (R)" to "8.314462618 J mol⁻¹ K⁻¹", "Boltzmann constant (k)" to "1.380649 × 10⁻²³ J K⁻¹", "Standard gravity (g₀)" to "9.80665 m/s²"
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        constants.forEach { (name, value) ->
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(name, style = MaterialTheme.typography.titleSmall); Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha=.7f)) }
                    TextButton(onClick = { onCopy(value) }) { Text("Copy") }
                }
            }
        }
    }
}


@Composable
private fun FractionTool() {
    var decimal by remember { mutableStateOf("0.75") }
    var fraction by remember { mutableStateOf("3/4") }
    val a = runCatching { AdvancedMath.decimalToFraction(decimal.toDouble()) }
    val b = runCatching { AdvancedMath.fractionToDecimal(fraction) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Decimal to fraction", style = MaterialTheme.typography.titleMedium)
        NumberField("Decimal number", decimal, { decimal = it }, Modifier.fillMaxWidth())
        ResultCard(a.getOrNull() ?: (a.exceptionOrNull()?.message ?: "Enter a valid decimal"))
        Divider()
        Text("Fraction to decimal", style = MaterialTheme.typography.titleMedium)
        NumberField("Fraction (e.g. 3/4)", fraction, { fraction = it }, Modifier.fillMaxWidth())
        ResultCard(b.getOrNull()?.let { AdvancedMath.clean(it) } ?: (b.exceptionOrNull()?.message ?: "Enter a valid fraction"))
    }
}
