package com.smb.scientificcalculator.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF6558D3)
private val LightScheme = lightColorScheme(
    primary = Accent, onPrimary = Color.White, secondary = Color(0xFF008C95),
    background = Color(0xFFF7F7FB), surface = Color.White, surfaceVariant = Color(0xFFECECF5),
    onBackground = Color(0xFF171A2E), onSurface = Color(0xFF171A2E), error = Color(0xFFB3261E)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFB9B0FF), onPrimary = Color(0xFF21165F), secondary = Color(0xFF8CEAF0),
    background = Color(0xFF111321), surface = Color(0xFF1A1D2D), surfaceVariant = Color(0xFF282B3E),
    onBackground = Color(0xFFF2F1FF), onSurface = Color(0xFFF2F1FF), error = Color(0xFFFFB4AB)
)

@Composable
fun ScienceCalculatorTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (darkTheme) DarkScheme else LightScheme, content = content)
}
