package com.smb.scientificcalculator.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class CalculatorEngineTest {
    private val engine = CalculatorEngine()
    @Test fun respectsOperatorPrecedence() = assertEquals(14.0, engine.evaluate("2+3*4"), 1e-9)
    @Test fun supportsNestedParenthesesAndPowers() = assertEquals(512.0, engine.evaluate("2^(3^2)"), 1e-9)
    @Test fun supportsDegreeMode() = assertEquals(0.5, engine.evaluate("sin(30)", degrees = true), 1e-9)
    @Test fun supportsPercentageAndCombinations() {
        assertEquals(0.5, engine.evaluate("50%"), 1e-9)
        assertEquals(10.0, engine.evaluate("ncr(5,2)"), 1e-9)
    }
    @Test fun supportsVariableForGraphing() = assertEquals(9.0, engine.evaluate("x^2", variables = mapOf("x" to 3.0)), 1e-9)
    @Test fun rejectsDivideByZero() { assertThrows(ArithmeticException::class.java) { engine.evaluate("10/0") } }
    @Test fun rejectsUnknownIdentifiers() { assertThrows(IllegalArgumentException::class.java) { engine.evaluate("system(1)") } }
}
