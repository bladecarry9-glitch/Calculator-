package com.smb.scientificcalculator.core

import com.smb.scientificcalculator.converter.ConversionEngine
import org.junit.Assert.assertEquals
import org.junit.Test

class ConversionEngineTest {
    @Test fun convertsLength() = assertEquals(1000.0, ConversionEngine.convert(1.0, "Length", "Meter", "Millimeter"), 1e-9)
    @Test fun convertsTemperature() = assertEquals(0.0, ConversionEngine.convert(32.0, "Temperature", "Fahrenheit", "Celsius"), 1e-9)
    @Test fun convertsTimeUnits() = assertEquals(60.0, ConversionEngine.convert(1.0, "Time", "Minute", "Second"), 1e-9)
    @Test fun convertsAngles() = assertEquals(kotlin.math.PI, ConversionEngine.convert(180.0, "Angle", "Degree", "Radian"), 1e-9)
}
