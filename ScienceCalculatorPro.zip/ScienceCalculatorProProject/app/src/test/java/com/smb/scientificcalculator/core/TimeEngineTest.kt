package com.smb.scientificcalculator.core

import com.smb.scientificcalculator.time.TimeEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test

class TimeEngineTest {
    @Test fun crossesMidnight() = assertEquals(7200L, TimeEngine.clockDifference("23:00:00", "01:00:00"))
    @Test fun supportsLongDurations() = assertEquals("27:00:00", TimeEngine.formatDuration(27 * 3600L))
    @Test fun formatsNegativeDifference() = assertEquals("−01:01:01", TimeEngine.formatDuration(-3661L))
    @Test fun rejectsInvalidClock() { assertThrows(IllegalArgumentException::class.java) { TimeEngine.parseClock("25:61") } }
}
