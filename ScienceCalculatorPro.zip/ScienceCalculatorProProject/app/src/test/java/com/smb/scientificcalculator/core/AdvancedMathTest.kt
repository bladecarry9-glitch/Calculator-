package com.smb.scientificcalculator.core

import com.smb.scientificcalculator.advanced.AdvancedMath
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AdvancedMathTest {
    @Test fun solvesQuadraticWithTwoRoots() {
        val result = AdvancedMath.solveQuadratic(1.0, -3.0, 2.0)
        assertTrue(result.contains("2.0000000")); assertTrue(result.contains("1.0000000"))
    }
    @Test fun computesStatistics() {
        val s = AdvancedMath.statistics("1,2,2,4")
        assertEquals(4, s.count); assertEquals(2.25, s.mean, 1e-9); assertEquals(2.0, s.median, 1e-9)
    }
    @Test fun matrixDeterminantIsCorrect() {
        val result = AdvancedMath.matrix(AdvancedMath.parseMatrix("1,2;3,4"), null, "Determinant")
        assertEquals("-2.0000000", result)
    }
    @Test fun statisticsRejectInvalidTokens() {
        assertTrue(runCatching { AdvancedMath.statistics("1, hello, 3") }.isFailure)
    }
    @Test fun fractionConversion() {
        assertEquals("3/4", AdvancedMath.decimalToFraction(0.75))
        assertEquals(0.75, AdvancedMath.fractionToDecimal("3/4"), 1e-9)
    }
}
