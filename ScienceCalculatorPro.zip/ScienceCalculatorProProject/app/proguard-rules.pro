# No custom rules are required for the initial non-minified release build.
