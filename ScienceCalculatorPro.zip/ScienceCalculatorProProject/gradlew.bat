@echo off
setlocal
set APP_HOME=%~dp0
set GRADLE_VERSION=8.9
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%APP_HOME%" %*
  exit /b %ERRORLEVEL%
)
set CACHE_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-%GRADLE_VERSION%-bin\manual
set GRADLE_BIN=%CACHE_DIR%\gradle-%GRADLE_VERSION%\bin\gradle.bat
if exist "%GRADLE_BIN%" (
  call "%GRADLE_BIN%" -p "%APP_HOME%" %*
  exit /b %ERRORLEVEL%
)
if not exist "%CACHE_DIR%" mkdir "%CACHE_DIR%"
set ZIP=%CACHE_DIR%\gradle-%GRADLE_VERSION%-bin.zip
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%ZIP%'"
if %ERRORLEVEL% NEQ 0 (
  echo Gradle download failed. Install Gradle %GRADLE_VERSION% or open the project in Android Studio with internet access.
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%CACHE_DIR%' -Force"
if %ERRORLEVEL% NEQ 0 exit /b %ERRORLEVEL%
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
